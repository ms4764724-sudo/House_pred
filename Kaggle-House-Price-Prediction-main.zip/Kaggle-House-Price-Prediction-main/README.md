# Kaggle-House-Price-Prediction
The goal of this Kaggle project is to predict house prices using Advanced Regression models.
Our Project placed at position of 180 out of 5K teams (Top 4%) with RMSLE score of 0.11899. We used ensemble learning and hyperparameter optimization with 6 ML models. 
ML stack: Lasso regression, Ridge regression, SVR, lgbm, gbm and xgboost.
Data folder contains all the training and testing data, the solution.ipynb contains the code.
![image](https://user-images.githubusercontent.com/63466198/144099075-7abe03fa-b4c4-4915-b813-e116c944b6d6.png)
